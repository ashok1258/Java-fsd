package map;
import java.util.*;
public class Map_Program {
	
		public static void main(String[] args) {
			
			//Hashmap
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Ravuru");    
		      hm.put(2,"Ashok");    
		      hm.put(3,"Reddy");   
		       
		      System.out.println("\nThe elements of Hashmap are "); 
		      System.out.println("**********************");
		      for(Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable 
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"Swathi");  
		      ht.put(5,"Sai");  
		      ht.put(6,"John");  
		      ht.put(7,"Madhu");  

		      System.out.println("\nThe elements of HashTable are ");  
		      System.out.println("**********************");
		      for(Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      //TreeMap
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"Sekhar");    
		      map.put(9,"Ram");    
		      map.put(10,"Praveen");       
		      
		      System.out.println("\nThe elements of TreeMap are ");
		      System.out.println("**********************");
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}


