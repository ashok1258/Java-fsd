package typeCasting;

public class Type_Caste {
	public static void main(String[]args) {
		   System.out.println("Implicit type cating");
		   System.out.println("----------------------");
		   
		   //implicitly type conversion
		   int a='1';
		   System.out.println("The value of  a is :"+a);
		   float b=a;
		   System.out.println("The value of  b is :"+b);
		   double c=a;
		   System.out.println("The value of  c is :"+c);
		   
		   System.out.println("Explicit type cating");
		   System.out.println("----------------------");
		   
		  //explicitly type convertion using type casting operator
		   double d=23.44;
		   float f=18.12f;
		   System.out.println("The value of  d is :"+(int)d);
		   System.out.println("The value of  f is :"+(int)f);
	}

}
