package try_catch;

public class TryCatch_Program {
	public static void main(String[] args) {
		System.out.println("Main method starts here");
		try {
			int a=10/0;
			System.out.println(a);
		}
		catch (ArithmeticException e) {
			System.out.println("Exception Handled");
		}
	}

}
