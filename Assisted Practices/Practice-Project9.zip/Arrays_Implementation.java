package arrays;

public class Arrays_Implementation {
	public static void main(String[] args) {

		//single-dimensional array
		int a[]= {10,20,30,40,50};
		
		for(int i=0;i<a.length;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}
  System.out.println();
  System.out.println("2-Dimensional array")
  ;
  System.out.println("------------");
		//multidimensional array
         int b[][]= {{1,2,3},{4,5,6},{7,8,9}};
         //to create rows
         for(int i=0;i<b.length;i++) {
        	 //to create columns
        	 for(int j=0;j<b.length;j++) {
        		 System.out.print(b[i][j]+" ");
        	 }
        	 System.out.println();
         }
         
		}
}

