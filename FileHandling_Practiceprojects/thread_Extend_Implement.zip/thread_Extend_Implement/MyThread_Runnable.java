package thread_Extend_Implement;

public class MyThread_Runnable implements Runnable{

	@Override
	public void run() {
		for(int i=1;i<=3;i++) {
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		MyThread_Runnable mtr=new MyThread_Runnable();
		Thread t=new Thread(mtr);
		t.start();
		
	}

}
