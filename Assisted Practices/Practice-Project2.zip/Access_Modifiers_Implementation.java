package accessModifiers;

public class Access_Modifiers_Implementation {

	    // Public members can access from anywhere
	    public int publicVar = 10;

	    // Private members will be access only within same class
	    private int privateVar = 20;

	    // Protected member accessible within same class and its subclasses
	    protected int protectedVar = 30;

	    // Package-private member accessible within the same package
	    int packagePrivateVar = 40;

	    // Public method accessible from anywhere
	    public void publicMethod() {
	        System.out.println("Public method called");
	    }

	    // Private method accessible only within this class
	    private void privateMethod() {
	        System.out.println("Private method called");
	    }

	    // Protected method accessible within this class and its subclasses
	    protected void protectedMethod() {
	        System.out.println("Protected method called");
	    }

	    // Package-private method accessible within the same package
	    void packagePrivateMethod() {
	        System.out.println("Package-private method called");
	    }

	    public static void main(String[] args) {
	    	Access_Modifiers_Implementation example = new Access_Modifiers_Implementation();

	        // Accessing members and methods
	        System.out.println("Public variable: " + example.publicVar);
	        System.out.println("Private variable: " + example.privateVar); // This will result in a compilation error
	        System.out.println("Protected variable: " + example.protectedVar);
	        System.out.println("Package-private variable: " + example.packagePrivateVar);

	        example.publicMethod();
	        example.privateMethod(); // This will result in a compilation error
	        example.protectedMethod();
	        example.packagePrivateMethod();
	    }
	}

