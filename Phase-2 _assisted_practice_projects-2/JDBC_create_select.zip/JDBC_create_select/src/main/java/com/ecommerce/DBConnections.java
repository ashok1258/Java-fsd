package com.ecommerce;

public class DBConnections {

}
