package innerclass;

public class Inner_Class_Program {
		public static void main(String[] args) {
	        // Creating an instance of OuterClass
	        OuterClass.InnerClass inner = new OuterClass().new InnerClass();

	        // Calling  methods on inner class instance
	        inner.method1();
	        inner.method2();
	    }
	}

	class OuterClass {
	    private int outerVar = 101;

	    class InnerClass {
	        private int innerVar = 201;

	        void method1() {
	            System.out.println("Method1 called from InnerClass. Outer variable accessed: " + outerVar);
	        }

	        void method2() {
	            System.out.println("Method2 called from InnerClass. Inner variable accessed: " + innerVar);
	        }
	    }
	}

