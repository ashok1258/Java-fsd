package constructor;

public class StudentDetails {

		String name;
		int rollno;
		
		//Constructor Without Arguments
		StudentDetails()
			
		{
		
			name="Ashok";
			rollno=2587557;
		}
		
		//constructor with argument
		StudentDetails(String str,int n)
		{
			name = str;
			rollno=n;
		}
		
		public static void main(String args[])
		{
			//Default Constructor
			StudentDetails s1= new StudentDetails();
			//creating second object with parametarized constructor
			//parametarized constructor
			StudentDetails s2 = new StudentDetails("Sai",234682);
			System.out.println(s1.name);
			System.out.println(s1.rollno);
			System.out.println(s2.name);
			System.out.println(s2.rollno);
			
		}
	}

